<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 4.7.9
 */

/**
 * Database `hmp`
 */

/* `hmp`.`contributor_request` */
$contributor_request = array(
);

/* `hmp`.`donations` */
$donations = array(
);

/* `hmp`.`issues` */
$issues = array(
  array('id' => '1','user_id' => '3','project_id' => '2','issue' => 'App built for the English language, how about Spanish, French and German? I recommend the symfony 4.3 Translator component.','created_at' => '2019-04-23 11:04:13'),
  array('id' => '2','user_id' => '3','project_id' => '3','issue' => 'Can\'t work with safari browser? Solve this','created_at' => '2019-04-23 11:07:22'),
  array('id' => '3','user_id' => '2','project_id' => '5','issue' => 'Music takes long to sync!! in the ipad 3rd Model?','created_at' => '2019-04-23 11:38:49'),
  array('id' => '4','user_id' => '2','project_id' => '5','issue' => 'Can\'t work with safari browser? Solve this','created_at' => '2019-05-01 10:10:31'),
  array('id' => '5','user_id' => '2','project_id' => '5','issue' => 'Can\'t work with safari browser? Solve this','created_at' => '2019-05-01 10:10:38')
);

/* `hmp`.`migration_versions` */
$migration_versions = array(
  array('version' => '20190422164642','executed_at' => '2019-04-22 16:46:56'),
  array('version' => '20190422182241','executed_at' => '2019-04-22 20:45:55'),
  array('version' => '20190422203436','executed_at' => '2019-04-22 20:35:30'),
  array('version' => '20190422204414','executed_at' => '2019-04-22 20:49:12'),
  array('version' => '20190422205705','executed_at' => '2019-04-22 20:57:23'),
  array('version' => '20190424183645','executed_at' => '2019-04-24 18:37:03'),
  array('version' => '20190424211938','executed_at' => '2019-04-28 11:08:47'),
  array('version' => '20190428111959','executed_at' => '2019-04-28 11:20:12'),
  array('version' => '20190502100843','executed_at' => '2019-05-02 10:09:11'),
  array('version' => '20190502101538','executed_at' => '2019-05-02 10:15:47'),
  array('version' => '20190502101641','executed_at' => '2019-05-02 10:16:52'),
  array('version' => '20190502134520','executed_at' => '2019-05-02 13:46:00'),
  array('version' => '20190502182248','executed_at' => '2019-05-02 18:23:47'),
  array('version' => '20190502200352','executed_at' => '2019-05-02 20:04:01')
);

/* `hmp`.`project` */
$project = array(
  array('id' => '2','user_id' => '2','title' => 'Voice Recognition App','icon' => '5ed8478bdf07410e1285baa2aaf4672f.png','description' => 'The app is powered by Google voice recognition tech. When you\'re recording a note, you can easily dictate punctuation marks through voice commands, or by using the built-in punctuation keyboard.','published_at' => '2019-04-28 11:21:16','category' => 'Web'),
  array('id' => '3','user_id' => '2','title' => 'w3 schools Api','icon' => '6366c5d7be93bb8cef6cdf25e67f480e.jpeg','description' => 'W3Schools API is optimized for learning, testing, and training.','published_at' => '2019-04-28 11:23:58','category' => 'Web'),
  array('id' => '4','user_id' => '3','title' => 'MakEssense Work Blog','icon' => '50aa2f8ca0e75d316428d280418f99d8.png','description' => 'Start a course work forum, anywhere at anytime. Compatible with chrome and firefox Add Ons extensions','published_at' => '2019-04-23 11:06:16','category' => NULL),
  array('id' => '5','user_id' => '3','title' => 'Itunes Music Skin','icon' => 'f403eb9bff23a565d0b4f5c4a756ac84.png','description' => 'iTunes Music Skin is a media player skin that provides media library, and Internet radio broadcaster web service.','published_at' => '2019-04-23 11:25:43','category' => NULL),
  array('id' => '6','user_id' => '3','title' => 'AppStore API','icon' => 'df56e078cb4e0d510dd92af53a3dba7e.png','description' => 'The AppStore API allows users to browse and download apps developed with Apple\'s iOS software development kit.','published_at' => '2019-04-23 11:30:58','category' => NULL),
  array('id' => '7','user_id' => '2','title' => 'Love Match','icon' => '5d58047db6e7afe8d935090a9cc6d9c2.png','description' => 'Love match is a couples APP and provides better communication experience & better way to stay in touch with your favorite person. Sending messages, voice messages, pictures e.t.c','published_at' => '2019-04-23 11:36:08','category' => NULL),
  array('id' => '8','user_id' => '2','title' => 'Delicious Code API','icon' => 'e74af0627572b9295125172539ae73d6.png','description' => 'Instead of handling file uploading yourself, you may consider using the Delicious Code API. This API provides all the common operations (such as file renaming, saving and deleting) and it\'s tightly integrated with Doctrine ORM.','published_at' => '2019-04-23 14:04:21','category' => NULL)
);

/* `hmp`.`projectfiles` */
$projectfiles = array(
  array('id' => '1','project_id' => '2','user_id' => '2','projectfile' => 'c663935204c4e7ebbcf093c794b32772.zip','created_at' => '2019-04-24 18:37:53','version_name' => NULL,'features' => NULL),
  array('id' => '2','project_id' => '2','user_id' => '2','projectfile' => '6d2e0f25a52f3858ece44236b14d1379.zip','created_at' => '2019-04-24 20:27:51','version_name' => NULL,'features' => NULL),
  array('id' => '3','project_id' => '2','user_id' => '2','projectfile' => 'a7a24f3e1ffbf1ce5cf490ecade47632.zip','created_at' => '2019-04-24 20:28:29','version_name' => NULL,'features' => NULL),
  array('id' => '4','project_id' => '2','user_id' => '2','projectfile' => 'c4259213f15e36170cbda7ac4d122c5f.zip','created_at' => '2019-04-24 22:33:01','version_name' => NULL,'features' => NULL),
  array('id' => '5','project_id' => '7','user_id' => '2','projectfile' => 'a8697edcfa5f4c28256885278d1ee77d.zip','created_at' => '2019-04-24 22:39:33','version_name' => NULL,'features' => NULL),
  array('id' => '6','project_id' => '2','user_id' => '2','projectfile' => '000e6202e5f30a91573df5713b22952e.zip','created_at' => '2019-05-01 10:04:57','version_name' => NULL,'features' => NULL),
  array('id' => '7','project_id' => '2','user_id' => '2','projectfile' => '0edbe37436e06ca235ff6ff932051173.zip','created_at' => '2019-05-02 12:54:56','version_name' => '1.1 Beta','features' => NULL),
  array('id' => '8','project_id' => '2','user_id' => '2','projectfile' => 'b52b5e2e0f349266c05df491602b96f1.zip','created_at' => '2019-05-02 19:23:09','version_name' => '1.3.1 Beta plus','features' => 'Bug fixes, Support for Languages: spanish and german.'),
  array('id' => '9','project_id' => '2','user_id' => '2','projectfile' => 'c631b0aa5d2a5ff1d98df6fb0933f51c.zip','created_at' => '2019-05-02 19:23:27','version_name' => '1.3.1 Beta plus','features' => 'Bug fixes, Support for Languages: spanish and german.'),
  array('id' => '10','project_id' => '3','user_id' => '2','projectfile' => '2dcb4021931730710dce34b7d2b8fab8.zip','created_at' => '2019-05-02 19:29:54','version_name' => '1.1 nero -V','features' => 'Bug Fixes, Python Support'),
  array('id' => '11','project_id' => '3','user_id' => '2','projectfile' => '23d7db319ececa711dc5c2b614647788.zip','created_at' => '2019-05-02 19:32:59','version_name' => '1.1 nero -V','features' => 'Bug Fixes, Python Support'),
  array('id' => '12','project_id' => '3','user_id' => '2','projectfile' => '80e747b49f352cd8402114faa2fd03c2.zip','created_at' => '2019-05-02 19:51:46','version_name' => '1.1.2 nero -V','features' => 'Bug fixes, Python Support, C++ and C# Support,'),
  array('id' => '13','project_id' => '2','user_id' => '2','projectfile' => '996d884648350b9a7e6df0bd3aafe56d.zip','created_at' => '2019-05-02 19:53:14','version_name' => '1.4.1 Beta plus','features' => 'Bug fixes, Support for Languages: Spanish, Latin , Kiswahili and German.')
);

/* `hmp`.`screenshot` */
$screenshot = array(
  array('id' => '1','project_id' => '2','user_id' => '2','screenshot' => 'd70245c3172b3f7aaf9efc60e699f070.png'),
  array('id' => '2','project_id' => '3','user_id' => '2','screenshot' => 'f175973052e7b7702dbd1c6d2634e570.png'),
  array('id' => '3','project_id' => '3','user_id' => '2','screenshot' => 'e36b6a0a9c38853f5a0eae3a3144436d.png'),
  array('id' => '4','project_id' => '2','user_id' => '2','screenshot' => '6058302beb4a0614b993ed378ceb04f6.png')
);

/* `hmp`.`user` */
$user = array(
  array('id' => '1','username' => 'admin','roles' => '["ROLE_ADMIN"]','password' => '$argon2i$v=19$m=1024,t=2,p=2$MmtsejZKZ0s0L2Y0bk0yNA$KgEoyagLBAoGBzA6RQ1OEhoYupcpQcFnIQC2F64RfO8','email' => 'mandeallanbenjamin@gmail.com'),
  array('id' => '2','username' => 'mandiallabenj','roles' => '[]','password' => '$argon2i$v=19$m=1024,t=2,p=2$Zk50R3c5R0RtdlVhVFBkWQ$FS2f6WFMJh9l1NSTGkWbTOtbB2WHBWGOCV24XGiCAfs','email' => 'allan.m.b@aol.com'),
  array('id' => '3','username' => 'elos','roles' => '[]','password' => '$argon2i$v=19$m=1024,t=2,p=2$MDFyUDM4bVBIUVk5VHVpbQ$/ppswZEGmkxcd9XmF9G79iLlDE0pJWZ4+3MF2cgBc2U','email' => 'allan.m.b@aol.com')
);
