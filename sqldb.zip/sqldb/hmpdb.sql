-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 03, 2019 at 08:35 PM
-- Server version: 5.7.21
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hmp`
--

--
-- Dumping data for table `issues`
--

INSERT INTO `issues` (`id`, `user_id`, `project_id`, `issue`, `created_at`) VALUES
(1, 3, 2, 'App built for the English language, how about Spanish, French and German? I recommend the symfony 4.3 Translator component.', '2019-04-23 11:04:13'),
(2, 3, 3, 'Can\'t work with safari browser? Solve this', '2019-04-23 11:07:22'),
(3, 2, 5, 'Music takes long to sync!! in the ipad 3rd Model?', '2019-04-23 11:38:49'),
(4, 2, 5, 'Can\'t work with safari browser? Solve this', '2019-05-01 10:10:31'),
(5, 2, 5, 'Can\'t work with safari browser? Solve this', '2019-05-01 10:10:38');

--
-- Dumping data for table `migration_versions`
--

INSERT INTO `migration_versions` (`version`, `executed_at`) VALUES
('20190422164642', '2019-04-22 16:46:56'),
('20190422182241', '2019-04-22 20:45:55'),
('20190422203436', '2019-04-22 20:35:30'),
('20190422204414', '2019-04-22 20:49:12'),
('20190422205705', '2019-04-22 20:57:23'),
('20190424183645', '2019-04-24 18:37:03'),
('20190424211938', '2019-04-28 11:08:47'),
('20190428111959', '2019-04-28 11:20:12'),
('20190502100843', '2019-05-02 10:09:11'),
('20190502101538', '2019-05-02 10:15:47'),
('20190502101641', '2019-05-02 10:16:52'),
('20190502134520', '2019-05-02 13:46:00'),
('20190502182248', '2019-05-02 18:23:47'),
('20190502200352', '2019-05-02 20:04:01');

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `user_id`, `title`, `icon`, `description`, `published_at`, `category`) VALUES
(2, 2, 'Voice Recognition App', '5ed8478bdf07410e1285baa2aaf4672f.png', 'The app is powered by Google voice recognition tech. When you\'re recording a note, you can easily dictate punctuation marks through voice commands, or by using the built-in punctuation keyboard.', '2019-04-28 11:21:16', 'Web'),
(3, 2, 'w3 schools Api', '6366c5d7be93bb8cef6cdf25e67f480e.jpeg', 'W3Schools API is optimized for learning, testing, and training.', '2019-04-28 11:23:58', 'Web'),
(4, 3, 'MakEssense Work Blog', '50aa2f8ca0e75d316428d280418f99d8.png', 'Start a course work forum, anywhere at anytime. Compatible with chrome and firefox Add Ons extensions', '2019-04-23 11:06:16', NULL),
(5, 3, 'Itunes Music Skin', 'f403eb9bff23a565d0b4f5c4a756ac84.png', 'iTunes Music Skin is a media player skin that provides media library, and Internet radio broadcaster web service.', '2019-04-23 11:25:43', NULL),
(6, 3, 'AppStore API', 'df56e078cb4e0d510dd92af53a3dba7e.png', 'The AppStore API allows users to browse and download apps developed with Apple\'s iOS software development kit.', '2019-04-23 11:30:58', NULL),
(7, 2, 'Love Match', '5d58047db6e7afe8d935090a9cc6d9c2.png', 'Love match is a couples APP and provides better communication experience & better way to stay in touch with your favorite person. Sending messages, voice messages, pictures e.t.c', '2019-04-23 11:36:08', NULL),
(8, 2, 'Delicious Code API', 'e74af0627572b9295125172539ae73d6.png', 'Instead of handling file uploading yourself, you may consider using the Delicious Code API. This API provides all the common operations (such as file renaming, saving and deleting) and it\'s tightly integrated with Doctrine ORM.', '2019-04-23 14:04:21', NULL);

--
-- Dumping data for table `projectfiles`
--

INSERT INTO `projectfiles` (`id`, `project_id`, `user_id`, `projectfile`, `created_at`, `version_name`, `features`) VALUES
(1, 2, 2, 'c663935204c4e7ebbcf093c794b32772.zip', '2019-04-24 18:37:53', NULL, NULL),
(2, 2, 2, '6d2e0f25a52f3858ece44236b14d1379.zip', '2019-04-24 20:27:51', NULL, NULL),
(3, 2, 2, 'a7a24f3e1ffbf1ce5cf490ecade47632.zip', '2019-04-24 20:28:29', NULL, NULL),
(4, 2, 2, 'c4259213f15e36170cbda7ac4d122c5f.zip', '2019-04-24 22:33:01', NULL, NULL),
(5, 7, 2, 'a8697edcfa5f4c28256885278d1ee77d.zip', '2019-04-24 22:39:33', NULL, NULL),
(6, 2, 2, '000e6202e5f30a91573df5713b22952e.zip', '2019-05-01 10:04:57', NULL, NULL),
(7, 2, 2, '0edbe37436e06ca235ff6ff932051173.zip', '2019-05-02 12:54:56', '1.1 Beta', NULL),
(8, 2, 2, 'b52b5e2e0f349266c05df491602b96f1.zip', '2019-05-02 19:23:09', '1.3.1 Beta plus', 'Bug fixes, Support for Languages: spanish and german.'),
(9, 2, 2, 'c631b0aa5d2a5ff1d98df6fb0933f51c.zip', '2019-05-02 19:23:27', '1.3.1 Beta plus', 'Bug fixes, Support for Languages: spanish and german.'),
(10, 3, 2, '2dcb4021931730710dce34b7d2b8fab8.zip', '2019-05-02 19:29:54', '1.1 nero -V', 'Bug Fixes, Python Support'),
(11, 3, 2, '23d7db319ececa711dc5c2b614647788.zip', '2019-05-02 19:32:59', '1.1 nero -V', 'Bug Fixes, Python Support'),
(12, 3, 2, '80e747b49f352cd8402114faa2fd03c2.zip', '2019-05-02 19:51:46', '1.1.2 nero -V', 'Bug fixes, Python Support, C++ and C# Support,'),
(13, 2, 2, '996d884648350b9a7e6df0bd3aafe56d.zip', '2019-05-02 19:53:14', '1.4.1 Beta plus', 'Bug fixes, Support for Languages: Spanish, Latin , Kiswahili and German.');

--
-- Dumping data for table `screenshot`
--

INSERT INTO `screenshot` (`id`, `project_id`, `user_id`, `screenshot`) VALUES
(1, 2, 2, 'd70245c3172b3f7aaf9efc60e699f070.png'),
(2, 3, 2, 'f175973052e7b7702dbd1c6d2634e570.png'),
(3, 3, 2, 'e36b6a0a9c38853f5a0eae3a3144436d.png'),
(4, 2, 2, '6058302beb4a0614b993ed378ceb04f6.png');

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `roles`, `password`, `email`) VALUES
(1, 'admin', '[\"ROLE_ADMIN\"]', '$argon2i$v=19$m=1024,t=2,p=2$MmtsejZKZ0s0L2Y0bk0yNA$KgEoyagLBAoGBzA6RQ1OEhoYupcpQcFnIQC2F64RfO8', 'mandeallanbenjamin@gmail.com'),
(2, 'mandiallabenj', '[]', '$argon2i$v=19$m=1024,t=2,p=2$Zk50R3c5R0RtdlVhVFBkWQ$FS2f6WFMJh9l1NSTGkWbTOtbB2WHBWGOCV24XGiCAfs', 'allan.m.b@aol.com'),
(3, 'elos', '[]', '$argon2i$v=19$m=1024,t=2,p=2$MDFyUDM4bVBIUVk5VHVpbQ$/ppswZEGmkxcd9XmF9G79iLlDE0pJWZ4+3MF2cgBc2U', 'allan.m.b@aol.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
